package web.pitza.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PitzaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
