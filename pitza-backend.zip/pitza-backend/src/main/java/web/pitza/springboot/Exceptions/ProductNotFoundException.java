package web.pitza.springboot.Exceptions;

public class ProductNotFoundException extends Exception{
	public ProductNotFoundException(String s) {
		super(s);
	}

}
